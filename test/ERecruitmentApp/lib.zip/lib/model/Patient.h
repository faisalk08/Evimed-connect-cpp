/*
 * Patient.h
 *
 *  Created on: Feb 14, 2013
 *      Author: indra
 */

#ifndef PATIENT_H_
#define PATIENT_H_
#include <EvimedModel.h>
namespace model {

class Patient : public EvimedModel{
public:
	Patient();
	virtual ~Patient();
};

} /* namespace model */
#endif /* PATIENT_H_ */
